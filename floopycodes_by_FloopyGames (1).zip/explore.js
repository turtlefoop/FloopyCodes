class ProjectExplorer {
  constructor() {
    this.setupEventListeners();
  }

  setupEventListeners() {
    // Safely attempt to find and bind the explore button
    const exploreBtn = document.getElementById('explore-btn');
    if (exploreBtn) {
      exploreBtn.addEventListener('click', () => this.openExploreModal());
    } else {
      console.warn('Explore button not found');
    }
  }

  openExploreModal() {
    // Remove any existing modals using standard Bootstrap modal hiding method
    const existingModal = document.getElementById('exploreModal');
    if (existingModal) {
      const bootstrapModal = bootstrap.Modal.getInstance(existingModal);
      if (bootstrapModal) {
        bootstrapModal.hide();
      }
      existingModal.remove();
    }

    // Remove any existing modal backdrops
    const existingBackdrop = document.querySelector('.modal-backdrop');
    if (existingBackdrop) {
      existingBackdrop.remove();
    }

    // Reset body classes that might have been added by previous modal
    document.body.classList.remove('modal-open');
    document.body.style.overflow = '';
    document.body.style.paddingRight = '';

    try {
      // First, remove any existing modals to prevent stacking

      const modalHtml = `
        <div class="modal fade" id="exploreModal" tabindex="-1">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Explore Projects</h5>
                <div class="input-group ms-3" style="width: 300px;">
                  <input type="text" id="project-search" class="form-control" placeholder="Search projects...">
                  <button class="btn btn-outline-secondary" type="button" id="search-btn">
                    <i class="bi bi-search"></i>
                  </button>
                </div>
                <div class="ms-auto">
                  <select id="project-filter" class="form-select form-select-sm" style="width: 200px;">
                    <option value="recent">Most Recent</option>
                    <option value="popular">Most Popular</option>
                    <option value="templates">Templates</option>
                    <option value="my-projects">My Projects</option>
                    <option value="all">All Projects</option>
                  </select>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="row" id="projectsContainer">
                  <!-- Projects will be dynamically loaded here -->
                </div>
              </div>
              <div class="modal-footer">
                <div id="pagination" class="d-flex justify-content-center align-items-center">
                  <button id="prev-page" class="btn btn-outline-secondary me-2">Previous</button>
                  <span id="page-info" class="mx-2">Page 1 of 1</span>
                  <button id="next-page" class="btn btn-outline-secondary ms-2">Next</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;

      // Create modal container
      const modalContainer = document.createElement('div');
      modalContainer.innerHTML = modalHtml;
      document.body.appendChild(modalContainer);

      // Initialize and show modal
      const exploreModal = document.getElementById('exploreModal');
      const bootstrapModal = new bootstrap.Modal(exploreModal, {
        backdrop: 'static', // Prevents closing on backdrop click
        keyboard: true      // Allows closing with ESC key
      });
      bootstrapModal.show();

      // Add an event listener to properly clean up when modal is hidden
      exploreModal.addEventListener('hidden.bs.modal', () => {
        // Remove the modal and its backdrop to prevent interaction issues
        exploreModal.remove();
        const backdrop = document.querySelector('.modal-backdrop');
        if (backdrop) {
          backdrop.remove();
        }
        
        // Remove any lingering body classes added by Bootstrap modal
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';
        document.body.style.paddingRight = '';
      });

      // Setup event listeners with null checks
      this.setupModalListeners();
      this.loadProjects();

    } catch (error) {
      console.error('Error in openExploreModal:', error);
      alert('Failed to open explore modal. Please try again.');
    }
  }

  setupModalListeners() {
    // Add comprehensive null checks for all event listeners
    const searchBtn = document.getElementById('search-btn');
    const searchInput = document.getElementById('project-search');
    const projectFilter = document.getElementById('project-filter');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');

    if (searchBtn) {
      searchBtn.addEventListener('click', () => this.loadProjects());
    }

    if (searchInput) {
      searchInput.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') this.loadProjects();
      });
    }

    if (projectFilter) {
      projectFilter.addEventListener('change', () => this.loadProjects());
    }

    if (prevPageBtn) {
      prevPageBtn.addEventListener('click', () => this.changePage(-1));
    }

    if (nextPageBtn) {
      nextPageBtn.addEventListener('click', () => this.changePage(1));
    }
  }

  loadProjects(page = 1) {
    const projectsContainer = document.getElementById('projectsContainer');
    if (!projectsContainer) {
      console.error('Projects container not found');
      return;
    }

    const searchInput = document.getElementById('project-search');
    const projectFilter = document.getElementById('project-filter');

    // Retrieve saved projects from localStorage
    let savedProjects = JSON.parse(localStorage.getItem('savedProjects') || '[]');

    // Apply search filter
    const searchTerm = (searchInput && searchInput.value) ? searchInput.value.toLowerCase().trim() : '';
    if (searchTerm) {
      savedProjects = savedProjects.filter(project => 
        project.name.toLowerCase().includes(searchTerm)
      );
    }

    // Apply filter
    const filterValue = (projectFilter && projectFilter.value) ? projectFilter.value : 'all';
    switch (filterValue) {
      case 'recent':
        savedProjects.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        break;
      case 'popular':
        savedProjects.sort((a, b) => (b.views || 0) - (a.views || 0));
        break;
      case 'templates':
        const templateNames = ['todo-app', 'calculator', 'landing-page', 'quiz-app', 'weather-app', 'game-2048'];
        savedProjects = savedProjects.filter(p => 
          templateNames.some(template => p.name.toLowerCase().includes(template))
        );
        break;
      case 'my-projects':
        // In a real app, this would filter by current user's projects
        break;
    }

    // Pagination
    const projectsPerPage = 9;
    const totalPages = Math.ceil(savedProjects.length / projectsPerPage);
    const startIndex = (page - 1) * projectsPerPage;
    const endIndex = startIndex + projectsPerPage;
    const paginatedProjects = savedProjects.slice(startIndex, endIndex);

    // Clear previous projects
    projectsContainer.innerHTML = '';

    if (paginatedProjects.length === 0) {
      projectsContainer.innerHTML = `
        <div class="col-12 text-center">
          <p class="text-muted">No projects found.</p>
        </div>
      `;
    } else {
      // Create project cards
      paginatedProjects.forEach(project => {
        const projectCard = this.createProjectCard(project);
        projectsContainer.appendChild(projectCard);
      });
    }

    // Update pagination
    const pageInfo = document.getElementById('page-info');
    if (pageInfo) {
      const prevPageBtn = document.getElementById('prev-page');
      const nextPageBtn = document.getElementById('next-page');

      pageInfo.textContent = `Page ${page} of ${totalPages || 1}`;
      if (prevPageBtn) {
        prevPageBtn.disabled = page === 1;
      }
      if (nextPageBtn) {
        nextPageBtn.disabled = page === totalPages;
      }
    }
  }

  createProjectCard(project) {
    const card = document.createElement('div');
    card.classList.add('col-md-4', 'mb-4');
    card.innerHTML = `
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">${project.name || 'Unnamed Project'}</h5>
          <p class="card-text text-muted small">
            Created: ${new Date(project.timestamp).toLocaleString()}
          </p>
          <div class="d-flex justify-content-between align-items-center">
            <div class="btn-group">
              <button class="btn btn-sm btn-outline-primary view-project" data-name="${project.name}">
                <i class="bi bi-eye"></i> View
              </button>
              <button class="btn btn-sm btn-outline-danger delete-project" data-name="${project.name}">
                <i class="bi bi-trash"></i> Delete
              </button>
            </div>
            <small class="text-muted">
              <i class="bi bi-code-slash"></i> 
              ${Object.keys(project).filter(key => ['html', 'css', 'js'].includes(key)).length} files
            </small>
          </div>
        </div>
      </div>
    `;

    // Add event listeners to buttons
    const viewBtn = card.querySelector('.view-project');
    const deleteBtn = card.querySelector('.delete-project');

    if (viewBtn) {
      viewBtn.addEventListener('click', () => this.viewProject(project));
    }
    if (deleteBtn) {
      deleteBtn.addEventListener('click', () => this.deleteProject(project.name));
    }

    return card;
  }

  viewProject(project) {
    try {
      // Update editors with project code
      const editors = {
        html: ace.edit("html-editor"),
        css: ace.edit("css-editor"),
        js: ace.edit("js-editor")
      };

      editors.html.setValue(project.html || '', -1);
      editors.css.setValue(project.css || '', -1);
      editors.js.setValue(project.js || '', -1);

      // Update project name input
      const projectNameInput = document.getElementById('project-name');
      if (projectNameInput) {
        projectNameInput.value = project.name || 'Unnamed Project';
      }

      // Run the project in preview
      const previewFrame = document.getElementById('preview-frame');
      if (previewFrame) {
        const combinedCode = `
          <!DOCTYPE html>
          <html>
            <head>
              <style>${project.css || ''}</style>
            </head>
            <body>
              ${project.html || ''}
              <script>${project.js || ''}<\/script>
            </body>
          </html>
        `;
        previewFrame.srcdoc = combinedCode;
      }

      // Close the modal
      const exploreModal = bootstrap.Modal.getInstance(document.getElementById('exploreModal'));
      if (exploreModal) {
        exploreModal.hide();
      }
    } catch (error) {
      console.error('Error in viewProject:', error);
    }
  }

  deleteProject(projectName) {
    try {
      if (!confirm(`Are you sure you want to delete the project "${projectName}"?`)) {
        return;
      }

      // Remove project from localStorage
      const savedProjects = JSON.parse(localStorage.getItem('savedProjects') || '[]');
      const updatedProjects = savedProjects.filter(p => p.name !== projectName);
      localStorage.setItem('savedProjects', JSON.stringify(updatedProjects));

      // Refresh projects
      this.loadProjects();
    } catch (error) {
      console.error('Error in deleteProject:', error);
    }
  }

  changePage(direction) {
    try {
      const pageInfo = document.getElementById('page-info');
      if (pageInfo) {
        const currentPage = parseInt(pageInfo.textContent.split(' ')[1]);
        const totalPages = parseInt(pageInfo.textContent.split(' ')[3]);

        const newPage = currentPage + direction;
        if (newPage >= 1 && newPage <= totalPages) {
          this.loadProjects(newPage);
        }
      }
    } catch (error) {
      console.error('Error in changePage:', error);
    }
  }

  static instance = null;
  
  static getInstance() {
    if (!ProjectExplorer.instance) {
      ProjectExplorer.instance = new ProjectExplorer();
    }
    return ProjectExplorer.instance;
  }
}

// Safely initialize ProjectExplorer
document.addEventListener('DOMContentLoaded', () => {
  try {
    // Use the static method to ensure single instance
    window.ProjectExplorer = ProjectExplorer;
  } catch (error) {
    console.error('Failed to initialize ProjectExplorer:', error);
  }
});