class WebCodeApp {
  constructor() {
    this.initializeEditors();
    this.initializeEventListeners();
    this.setupCollaboration();
    this.setupAICodeGenerator();
    this.setupFullscreenToggle();
    this.setupCodeValidation();
    this.setupCursorTracking();
    this.setupThemeSelector();
    this.setupAdvancedFeatures();
    this.setupProjectManagement();
    this.setupLanguageSupport();
  }

  initializeEditors() {
    const editorIds = {
      'html': 'html-editor',
      'css': 'css-editor',
      'js': 'js-editor',
      'ts': 'ts-editor',
      'py': 'py-editor',
      'json': 'json-editor',
      'jsx': 'jsx-editor'
    };

    this.editors = {};

    Object.entries(editorIds).forEach(([language, editorId]) => {
      const editorElement = document.getElementById(editorId);
      if (editorElement) {
        const editor = ace.edit(editorId);
        editor.setTheme("ace/theme/monokai");
        editor.setOptions({
          enableBasicAutocompletion: true,
          enableSnippets: true,
          enableLiveAutocompletion: true,
          fontSize: 14
        });

        // Set specific modes for each editor
        const languageModes = {
          'html': 'html',
          'css': 'css',
          'js': 'javascript',
          'ts': 'typescript',
          'py': 'python',
          'json': 'json',
          'jsx': 'jsx'
        };

        editor.session.setMode(`ace/mode/${languageModes[language]}`);
        this.editors[language] = editor;
      } else {
        console.warn(`Editor for ${language} not found`);
      }
    });
  }

  initializeEventListeners() {
    const runBtn = document.getElementById('run-btn');
    const newProjectBtn = document.getElementById('new-project-btn');
    const languageSelector = document.getElementById('language-selector');
    const downloadProjectBtn = document.getElementById('download-project-btn');

    if (runBtn) {
      runBtn.addEventListener('click', () => this.runCode());
    } else {
      console.warn('Run button not found');
    }

    if (newProjectBtn) {
      newProjectBtn.addEventListener('click', () => this.createNewProject());
    } else {
      console.warn('New project button not found');
    }

    if (languageSelector) {
      languageSelector.addEventListener('change', (e) => this.switchLanguage(e.target.value));
    } else {
      console.warn('Language selector not found');
    }

    if (downloadProjectBtn) {
      downloadProjectBtn.addEventListener('click', () => this.downloadProject());
    } else {
      console.warn('Download project button not found');
    }
  }

  setupCollaboration() {
    try {
      this.socket = io('https://your-websocket-server.com');
      
      this.socket.on('connect', () => {
        console.log('Connected to collaboration server');
      });

      this.socket.on('code-update', (data) => {
        this.updateEditorContent(data);
      });

      this.bindEditorChanges();
    } catch (error) {
      console.error('Collaboration setup failed', error);
    }
  }

  bindEditorChanges() {
    Object.entries(this.editors).forEach(([lang, editor]) => {
      editor.on('change', () => {
        const content = editor.getValue();
        this.socket.emit('code-change', { language: lang, content });
      });
    });
  }

  updateEditorContent(data) {
    if (this.editors[data.language]) {
      this.editors[data.language].setValue(data.content, -1);
    }
  }

  runCode() {
    const previewFrame = document.getElementById('preview-frame');
    
    // Combine HTML, CSS, and JS for preview
    const html = this.editors.html?.getValue() || '';
    const css = this.editors.css?.getValue() || '';
    const js = this.editors.js?.getValue() || '';

    const combinedCode = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>${css}</style>
        </head>
        <body>
          ${html}
          <script>${js}</script>
        </body>
      </html>
    `;

    previewFrame.srcdoc = combinedCode;

    // Log contents of other languages for reference
    const languages = ['ts', 'py', 'json', 'jsx'];
    languages.forEach(lang => {
      const code = this.editors[lang]?.getValue() || '';
      console.log(`${lang.toUpperCase()} Code:`, code);
    });
  }

  createNewProject() {
    Object.values(this.editors).forEach(editor => editor.setValue(''));
  }

  switchLanguage(language) {
    console.log(`Switched to ${language}`);
  }

  setupAICodeGenerator() {
    const aiGenerateBtn = document.getElementById('ai-generate-btn');
    const aiPromptInput = document.getElementById('ai-prompt');
    const aiSuggestionsContent = document.getElementById('ai-suggestions-content');

    // Add teaching mode toggle
    const teachingModeToggle = document.createElement('div');
    teachingModeToggle.innerHTML = `
      <div class="form-check form-switch ms-2">
        <input class="form-check-input" type="checkbox" id="ai-teaching-mode">
        <label class="form-check-label text-muted" for="ai-teaching-mode">
          Teaching Mode
        </label>
      </div>
    `;
    aiGenerateBtn.parentNode.insertBefore(teachingModeToggle, aiGenerateBtn.nextSibling);

    aiGenerateBtn.addEventListener('click', async () => {
      const prompt = aiPromptInput.value.trim();
      const isTeachingMode = document.getElementById('ai-teaching-mode').checked;

      if (!prompt) return;

      try {
        const suggestions = await this.generateAICodeSuggestions(prompt, isTeachingMode);
        this.displayAISuggestions(suggestions, isTeachingMode);
      } catch (error) {
        console.error('AI code generation failed', error);
        aiSuggestionsContent.innerHTML = '<p>Error generating AI suggestions</p>';
      }
    });
  }

  async generateAICodeSuggestions(prompt, isTeachingMode) {
    try {
      const response = await fetch('/api/ai_completion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({ 
          prompt: isTeachingMode 
            ? `Please provide an EDUCATIONAL explanation of code related to: ${prompt}. 
               Include:
               1. Detailed explanation of the concept
               2. Step-by-step breakdown
               3. Code example with comments
               4. Common pitfalls and best practices
               
               Format your response as a JSON object with these keys:
               - concept: Brief overview of the programming concept
               - explanation: Detailed explanation
               - steps: Array of learning steps
               - code_example: Code snippet with explanatory comments
               - best_practices: Tips and recommendations`
            : `Generate code based on this description: ${prompt}. 
               Provide code suggestions for HTML, CSS, or JavaScript depending on the context.
               Format your response as a JSON object with separate keys for html, css, and js.`,
          data: {
            currentHTML: this.editors.html.getValue(),
            currentCSS: this.editors.css.getValue(),
            currentJS: this.editors.js.getValue()
          }
        }),
      });

      if (!response.ok) {
        throw new Error('AI suggestion request failed');
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error fetching AI suggestions:', error);
      throw error;
    }
  }

  displayAISuggestions(suggestions, isTeachingMode) {
    const aiSuggestionsContent = document.getElementById('ai-suggestions-content');
    aiSuggestionsContent.innerHTML = '';

    if (isTeachingMode) {
      // Create an educational card
      const teachingCard = document.createElement('div');
      teachingCard.classList.add('card', 'mb-3');
      teachingCard.innerHTML = `
        <div class="card-header bg-primary text-white">
          <h5 class="mb-0"> Learning Module</h5>
        </div>
        <div class="card-body">
          <h6 class="card-title">${suggestions.concept || 'Programming Concept'}</h6>
          <p class="card-text">${suggestions.explanation || 'No detailed explanation available.'}</p>
          
          <div class="mt-3">
            <h6>Learning Steps:</h6>
            <ol class="pl-3">
              ${(suggestions.steps || []).map(step => `<li>${step}</li>`).join('')}
            </ol>
          </div>
          
          <div class="mt-3">
            <h6>Code Example:</h6>
            <pre class="bg-light p-2 rounded"><code>${suggestions.code_example || 'No code example available.'}</code></pre>
          </div>
          
          <div class="mt-3">
            <h6>Best Practices:</h6>
            <ul class="pl-3">
              ${(suggestions.best_practices || []).map(practice => `<li>${practice}</li>`).join('')}
            </ul>
          </div>
        </div>
      `;

      aiSuggestionsContent.appendChild(teachingCard);
    } else {
      // Existing code suggestion display logic
      const codeTypes = ['html', 'css', 'js'];
      codeTypes.forEach(type => {
        if (suggestions[type]) {
          const suggestionCard = document.createElement('div');
          suggestionCard.classList.add('suggestion-card');
          
          const titleEl = document.createElement('h4');
          titleEl.textContent = `${type.toUpperCase()} Suggestion`;
          
          const codeEl = document.createElement('pre');
          codeEl.textContent = suggestions[type];
          
          const applyBtn = document.createElement('button');
          applyBtn.textContent = 'Apply';
          applyBtn.addEventListener('click', () => {
            this.editors[type].setValue(suggestions[type], -1);
          });

          suggestionCard.appendChild(titleEl);
          suggestionCard.appendChild(codeEl);
          suggestionCard.appendChild(applyBtn);

          aiSuggestionsContent.appendChild(suggestionCard);
        }
      });
    }
  }

  setupFullscreenToggle() {
    const fullscreenBtn = document.getElementById('fullscreen-btn');
    const previewFrame = document.getElementById('preview-frame');

    fullscreenBtn.addEventListener('click', () => {
      if (!document.fullscreenElement) {
        if (previewFrame.requestFullscreen) {
          previewFrame.requestFullscreen();
        } else if (previewFrame.mozRequestFullScreen) { 
          previewFrame.mozRequestFullScreen();
        } else if (previewFrame.webkitRequestFullscreen) { 
          previewFrame.webkitRequestFullscreen();
        } else if (previewFrame.msRequestFullscreen) { 
          previewFrame.msRequestFullscreen();
        }
        previewFrame.classList.add('fullscreen');
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.mozCancelFullScreen) { 
          document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) { 
          document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) { 
          document.msExitFullscreen();
        }
        previewFrame.classList.remove('fullscreen');
      }
    });

    document.addEventListener('fullscreenchange', this.handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', this.handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    document.addEventListener('msfullscreenchange', this.handleFullscreenChange);
  }

  handleFullscreenChange = () => {
    const previewFrame = document.getElementById('preview-frame');
    if (!document.fullscreenElement) {
      previewFrame.classList.remove('fullscreen');
    }
  }

  setupAdvancedFeatures() {
    const formatCodeBtn = document.getElementById('format-code-btn');
    formatCodeBtn.addEventListener('click', () => this.formatCode());

    const clearSuggestionsBtn = document.getElementById('clear-suggestions-btn');
    clearSuggestionsBtn.addEventListener('click', () => {
      const aiSuggestionsContent = document.getElementById('ai-suggestions-content');
      aiSuggestionsContent.innerHTML = '';
    });

    this.setupEditorTabs();
  }

  setupEditorTabs() {
    const tabs = document.querySelectorAll('.editor-tabs .nav-link');
    const editors = {
      'index.html': document.getElementById('html-editor'),
      'styles.css': document.getElementById('css-editor'),
      'script.js': document.getElementById('js-editor')
    };

    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        Object.values(editors).forEach(editor => editor.style.display = 'none');

        editors[tab.dataset.file].style.display = 'block';
      });
    });
  }

  setupCursorTracking() {
    const cursorPosition = document.getElementById('cursor-position');
    
    Object.values(this.editors).forEach(editor => {
      editor.getSession().selection.on('changeCursor', () => {
        const position = editor.getCursorPosition();
        cursorPosition.textContent = `Ln: ${position.row + 1}, Col: ${position.column + 1}`;
      });
    });
  }

  setupCodeValidation() {
    const validateCodeBtn = document.getElementById('validate-code-btn');
    validateCodeBtn.addEventListener('click', () => this.validateCode());
  }

  validateCode() {
    try {
      const validationResults = {};
      Object.entries(this.editors).forEach(([lang, editor]) => {
        const code = editor.getValue();
        validationResults[lang] = this.languageValidators[lang](code);
      });

      this.displayValidationResults(validationResults);
    } catch (error) {
      console.error('Validation failed', error);
    }
  }

  setupLanguageSupport() {
    // Add language-specific validation and compilation methods
    this.languageValidators = {
      html: this.validateHTML.bind(this),
      css: this.validateCSS.bind(this),
      js: this.validateJS.bind(this),
      ts: this.validateTypeScript.bind(this),
      py: this.validatePython.bind(this),
      json: this.validateJSON.bind(this),
      jsx: this.validateReactJSX.bind(this)
    };

    // Add language-specific runners or compilation methods
    this.languageRunners = {
      html: this.runHTML.bind(this),
      css: this.runCSS.bind(this),
      js: this.runJavaScript.bind(this),
      ts: this.runTypeScript.bind(this),
      py: this.runPython.bind(this),
      json: this.displayJSON.bind(this),
      jsx: this.runReactJSX.bind(this)
    };
  }

  validateHTML(html) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const parserErrors = doc.querySelector('parsererror');
    return parserErrors ? parserErrors.textContent : 'Valid HTML';
  }

  validateCSS(css) {
    try {
      const stylesheet = document.createElement('style');
      stylesheet.textContent = css;
      document.head.appendChild(stylesheet);
      document.head.removeChild(stylesheet);
      return 'Valid CSS';
    } catch (error) {
      return `Invalid CSS: ${error.message}`;
    }
  }

  validateJS(js) {
    try {
      new Function(js);
      return 'Valid JavaScript';
    } catch (error) {
      return `Invalid JavaScript: ${error.message}`;
    }
  }

  validateTypeScript(code) {
    // Basic TypeScript validation 
    try {
      // In a real-world scenario, you'd use a more robust TypeScript compiler
      new Function(`"use strict"; ${code}`);
      return 'Valid TypeScript';
    } catch (error) {
      return `Invalid TypeScript: ${error.message}`;
    }
  }

  validatePython(code) {
    // Basic Python syntax check
    try {
      // Note: This is a very basic validation and won't catch all Python syntax errors
      const pythonSyntaxRegex = /^((?!import|def|class|if|else|elif|for|while|try|except|finally|with|return|yield|break|continue|pass|raise).)*$/s;
      if (pythonSyntaxRegex.test(code)) {
        return 'Valid Python syntax';
      }
      return 'Valid Python';
    } catch (error) {
      return `Invalid Python: ${error.message}`;
    }
  }

  validateJSON(code) {
    try {
      JSON.parse(code);
      return 'Valid JSON';
    } catch (error) {
      return `Invalid JSON: ${error.message}`;
    }
  }

  validateReactJSX(code) {
    // Very basic JSX validation
    try {
      // This is a placeholder. In a real app, you'd use Babel or a more robust parser
      new Function(`"use strict"; return ${code}`);
      return 'Valid React JSX';
    } catch (error) {
      return `Invalid React JSX: ${error.message}`;
    }
  }

  runHTML(code) {
    // You might want to add specialized rendering for HTML
    return code;
  }

  runCSS(code) {
    // You might want to add specialized rendering for CSS
    return code;
  }

  runJavaScript(code) {
    // You might want to add specialized rendering for JavaScript
    return code;
  }

  runTypeScript(code) {
    // In a real-world scenario, you'd use a TypeScript compiler like Babel
    return `// TypeScript compilation would happen here\n${code}`;
  }

  runPython(code) {
    // Note: Running Python in the browser is complex and typically requires a backend or WebAssembly
    return `# Python code would be processed server-side\n${code}`;
  }

  displayJSON(code) {
    try {
      const parsedJson = JSON.parse(code);
      return `<pre>${JSON.stringify(parsedJson, null, 2)}</pre>`;
    } catch (error) {
      return `Error parsing JSON: ${error.message}`;
    }
  }

  runReactJSX(code) {
    // Placeholder for React JSX rendering
    return `// React JSX would be compiled and rendered\n${code}`;
  }

  displayValidationResults(results) {
    const aiSuggestionsContent = document.getElementById('ai-suggestions-content');
    aiSuggestionsContent.innerHTML = `
      <div class="validation-results">
        <h5>Code Validation</h5>
        ${Object.keys(results).map(lang => `<p>${lang.toUpperCase()}: ${results[lang]}</p>`).join('')}
      </div>
    `;
  }

  setupThemeSelector() {
    const themeSelector = document.getElementById('theme-selector');
    
    themeSelector.addEventListener('change', (e) => {
      const theme = e.target.value;
      Object.values(this.editors).forEach(editor => {
        editor.setTheme(`ace/theme/${theme}`);
      });
    });
  }

  setupProjectManagement() {
    const projectNameInput = document.getElementById('project-name');
    const saveProjectBtn = document.getElementById('save-project-btn');
    const publishProjectBtn = document.getElementById('publish-project-btn');

    // Load last project name if exists
    const savedProjectName = localStorage.getItem('currentProjectName');
    if (savedProjectName) {
      projectNameInput.value = savedProjectName;
    }

    // Save project name when changed
    projectNameInput.addEventListener('change', () => {
      localStorage.setItem('currentProjectName', projectNameInput.value);
    });

    saveProjectBtn.addEventListener('click', () => this.saveProject());
    publishProjectBtn.addEventListener('click', () => this.publishProject());
  }

  saveProject() {
    const projectName = document.getElementById('project-name').value || 'Untitled Project';
    const projectData = {
      name: projectName,
      html: this.editors.html.getValue(),
      css: this.editors.css.getValue(),
      js: this.editors.js.getValue(),
      ts: this.editors.ts.getValue(),
      py: this.editors.py.getValue(),
      json: this.editors.json.getValue(),
      jsx: this.editors.jsx.getValue(),
      timestamp: new Date().toISOString()
    };

    try {
      // Save to localStorage
      const savedProjects = JSON.parse(localStorage.getItem('savedProjects') || '[]');
      const existingProjectIndex = savedProjects.findIndex(p => p.name === projectName);

      if (existingProjectIndex !== -1) {
        savedProjects[existingProjectIndex] = projectData;
      } else {
        savedProjects.push(projectData);
      }

      localStorage.setItem('savedProjects', JSON.stringify(savedProjects));
      
      this.showNotification('Project saved successfully!', 'success');
    } catch (error) {
      console.error('Save project failed', error);
      this.showNotification('Failed to save project', 'danger');
    }
  }

  publishProject() {
    const projectName = document.getElementById('project-name').value || 'Untitled Project';
    const projectData = {
      name: projectName,
      html: this.editors.html.getValue(),
      css: this.editors.css.getValue(),
      js: this.editors.js.getValue(),
      ts: this.editors.ts.getValue(),
      py: this.editors.py.getValue(),
      json: this.editors.json.getValue(),
      jsx: this.editors.jsx.getValue(),
      timestamp: new Date().toISOString()
    };

    try {
      // Save to localStorage for exploration
      const savedProjects = JSON.parse(localStorage.getItem('savedProjects') || '[]');
      const existingProjectIndex = savedProjects.findIndex(p => p.name === projectName);

      if (existingProjectIndex !== -1) {
        savedProjects[existingProjectIndex] = projectData;
      } else {
        savedProjects.push(projectData);
      }

      localStorage.setItem('savedProjects', JSON.stringify(savedProjects));
      
      this.showNotification('Project published successfully! It will appear in Explore.', 'success');
      
      // Simulating clipboard copy (in a real app, you'd generate a real shareable link)
      navigator.clipboard.writeText(`https://floopycodes.com/project/${projectName.toLowerCase().replace(/\s+/g, '-')}`);
    } catch (error) {
      console.error('Publish project failed', error);
      this.showNotification('Failed to publish project', 'danger');
    }
  }

  showNotification(message, type = 'info') {
    const notificationContainer = document.createElement('div');
    notificationContainer.className = `alert alert-${type} position-fixed top-0 start-50 translate-middle-x mt-3`;
    notificationContainer.style.zIndex = '1050';
    notificationContainer.textContent = message;

    document.body.appendChild(notificationContainer);

    setTimeout(() => {
      notificationContainer.remove();
    }, 3000);
  }

  formatCode() {
    try {
      const html = prettier.format(this.editors.html.getValue(), {
        parser: 'html',
        plugins: prettierPlugins
      });
      const css = prettier.format(this.editors.css.getValue(), {
        parser: 'css',
        plugins: prettierPlugins
      });
      const js = prettier.format(this.editors.js.getValue(), {
        parser: 'babel',
        plugins: prettierPlugins
      });

      this.editors.html.setValue(html, -1);
      this.editors.css.setValue(css, -1);
      this.editors.js.setValue(js, -1);
    } catch (error) {
      console.error('Code formatting failed', error);
    }
  }

  downloadProject() {
    const projectName = document.getElementById('project-name').value || 'Untitled Project';
    const projectData = {
      name: projectName,
      html: this.editors.html.getValue(),
      css: this.editors.css.getValue(),
      js: this.editors.js.getValue(),
      ts: this.editors.ts.getValue(),
      py: this.editors.py.getValue(),
      json: this.editors.json.getValue(),
      jsx: this.editors.jsx.getValue(),
      timestamp: new Date().toISOString()
    };

    try {
      const projectJson = JSON.stringify(projectData, null, 2);
      const blob = new Blob([projectJson], { type: 'application/json' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `${projectName}.json`;
      link.click();
      this.showNotification('Project downloaded successfully!', 'success');
    } catch (error) {
      console.error('Download project failed', error);
      this.showNotification('Failed to download project', 'danger');
    }
  }

}

document.addEventListener('DOMContentLoaded', () => {
  try {
    new WebCodeApp();
  } catch (error) {
    console.error('Failed to initialize WebCodeApp:', error);
    const appContainer = document.getElementById('app');
    if (appContainer) {
      appContainer.innerHTML = `
        <div class="alert alert-danger">
          <h3>Initialization Error</h3>
          <p>There was a problem loading the WebCode Pro application. Please try refreshing the page.</p>
          <small>Error details: ${error.message}</small>
        </div>
      `;
    }
  }
});